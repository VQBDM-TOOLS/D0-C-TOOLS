window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const d = event.data;
  if (!d || d.source !== "BANTUSAKU_AUTH_BRIDGE" || d.type !== "AUTH") return;
  chrome.runtime.sendMessage({
    type: "capturePageAuth",
    headers: d.headers || {},
    url: d.url || ""
  }).catch(() => {});
});
