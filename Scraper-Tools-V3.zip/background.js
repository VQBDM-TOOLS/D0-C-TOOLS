const SITE = "https://cco-agent.bantusaku.id/";

// Keep authentication headers in memory only. They are learned from API
// requests made by the currently open, logged-in tab and are never persisted.
const authByTab = new Map();
const AUTH_STORAGE_KEY = "__scraper_auth_by_tab";

async function saveAuthState() {
  try {
    const obj = {};
    for (const [tabId, headers] of authByTab) obj[String(tabId)] = headers;
    if (chrome.storage?.session) await chrome.storage.session.set({[AUTH_STORAGE_KEY]: obj});
  } catch (_) {}
}

async function restoreAuthState() {
  try {
    if (!chrome.storage?.session) return;
    const data = await chrome.storage.session.get(AUTH_STORAGE_KEY);
    const obj = data?.[AUTH_STORAGE_KEY] || {};
    for (const [tabId, headers] of Object.entries(obj)) {
      if (headers && typeof headers === "object" && Object.keys(headers).length) authByTab.set(Number(tabId), headers);
    }
  } catch (_) {}
}
const authReady = restoreAuthState();

chrome.runtime.onInstalled.addListener(async () => {
  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true});
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (chrome.sidePanel?.open && tab?.windowId) {
    try { await chrome.sidePanel.open({windowId: tab.windowId}); } catch (_) {}
  }
});

function safeFilename(name) {
  return String(name || "bantusaku-report.xlsx").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\.+$/g, "").slice(0,180) || "bantusaku-report.xlsx";
}

function isSiteApi(url) {
  return /^https:\/\/cco-agent\.bantusaku\.id\/api\//.test(url || "");
}

function isAuthHeader(name) {
  const n = String(name || "").toLowerCase();
  return n === "authorization" ||
    n === "x-access-token" ||
    n === "x-auth-token" ||
    n === "x-csrf-token" ||
    n === "x-xsrf-token";
}

if (chrome.webRequest?.onBeforeSendHeaders) {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      if (details.tabId == null || details.tabId < 0 || !isSiteApi(details.url)) return;
      const headers = {};
      for (const h of (details.requestHeaders || [])) {
        if (isAuthHeader(h.name) && h.value) headers[h.name] = h.value;
      }
      if (Object.keys(headers).length) { authByTab.set(details.tabId, headers); saveAuthState(); }
    },
    {urls: ["https://cco-agent.bantusaku.id/api/*"]},
    ["requestHeaders", "extraHeaders"]
  );
}

chrome.tabs.onRemoved.addListener((tabId) => { authByTab.delete(tabId); saveAuthState(); });

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  // Do NOT clear authentication merely because the user switches Chrome
  // windows/apps or a page starts loading. Those events do not mean the
  // session ended. Keep the last known auth and let fresh API requests
  // replace it when the site rotates/refreshes the token.
  if (changeInfo.url && !String(changeInfo.url).startsWith(SITE)) {
    authByTab.delete(tabId);
    saveAuthState();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "GET_AUTH_HEADERS") {
    const tabId = Number(msg.tabId ?? sender.tab?.id ?? -1);
    authReady.then(() => sendResponse({ok: true, headers: authByTab.get(tabId) || {}}));
    return true;
  }

  if (msg?.type === "SET_AUTH_HEADERS") {
    const tabId = Number(sender.tab?.id ?? msg.tabId ?? -1);
    const headers = msg.headers && typeof msg.headers === "object" ? msg.headers : {};
    if (tabId >= 0 && Object.keys(headers).length) {
      authByTab.set(tabId, headers);
      saveAuthState();
    }
    sendResponse({ok:true,tabId,headers:authByTab.get(tabId)||{}});
    return;
  }

  if (msg?.type === "GET_BEST_AUTH") {
    const requestedTabId = Number(msg.tabId ?? -1);
    if (requestedTabId >= 0 && authByTab.has(requestedTabId)) {
      sendResponse({ok:true, tabId:requestedTabId, headers:authByTab.get(requestedTabId)});
      return;
    }
    let best = null;
    for (const [tabId, headers] of authByTab) {
      if (!headers || !Object.keys(headers).length) continue;
      if (!best || Number(tabId) === Number(msg.preferredTabId)) best = {tabId, headers};
    }
    sendResponse(best ? {ok:true, ...best} : {ok:true, tabId:null, headers:{}});
    return;
  }

  if (msg?.type === "GET_CCO_TABS") {
    chrome.tabs.query({url:["https://cco-agent.bantusaku.id/*"]}).then(tabs => {
      const list = tabs.map(tab => ({id:tab.id, windowId:tab.windowId, url:tab.url, title:tab.title, hasAuth:authByTab.has(tab.id)}));
      list.sort((a,b) => Number(b.hasAuth)-Number(a.hasAuth));
      sendResponse({ok:true,tabs:list});
    }).catch(e => sendResponse({ok:false,error:String(e)}));
    return true;
  }

  if (msg?.type === "CLEAR_AUTH_HEADERS") {
    const tabId = Number(msg.tabId ?? sender.tab?.id ?? -1);
    authByTab.delete(tabId);
    saveAuthState();
    sendResponse({ok: true});
    return;
  }

  if (msg?.type === "DOWNLOAD_BINARY") {
    try {
      const b64=String(msg.base64||"");
      if(!b64 || b64.length>45_000_000) throw new Error("File terlalu besar untuk downloader extension.");
      const url=`data:${String(msg.mime||"application/octet-stream")};base64,${b64}`;
      chrome.downloads.download({url,filename:safeFilename(msg.filename),saveAs:false,conflictAction:"uniquify"})
        .then(id=>sendResponse({ok:true,id})).catch(e=>sendResponse({ok:false,error:String(e)}));
    } catch(e){ sendResponse({ok:false,error:String(e)}); }
    return true;
  }

  if (msg?.type === "DOWNLOAD_TEXT") {
    const bytes = new TextEncoder().encode(msg.text || "");
    const blob = new Blob([bytes], {type: msg.mime || "text/plain"});
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const id = await chrome.downloads.download({
          url: reader.result,
          filename: msg.filename || "bantusaku-export.txt",
          saveAs: true
        });
        sendResponse({ok:true,id});
      } catch (e) { sendResponse({ok:false,error:String(e)}); }
    };
    reader.readAsDataURL(blob);
    return true;
  }

  if (msg?.type === "GET_ACTIVE_TAB") {
    chrome.tabs.query({active:true,currentWindow:true}).then(tabs => {
      sendResponse({ok:true, tab: tabs[0] || null});
    });
    return true;
  }
});
