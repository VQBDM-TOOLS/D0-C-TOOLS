// Cloudflare Worker License Server
const LICENSE_SERVER_URL = "https://bantusaku-license.viqibudimansyah16.workers.dev";
