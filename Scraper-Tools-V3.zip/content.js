(() => {
  if (window.__bantusakuScraperLoaded) return;
  window.__bantusakuScraperLoaded = true;

  const ENDPOINTS = {
    cases: "/api/v1/collection/im-cases/select-cases",
    user: "/api/v1/collection/user/select-user-info",
    contacts: "/api/v1/collection/contact/select-user-contact-listing",
    completePhone: "/api/v1/collection/contact/select-complete-phone",
    repayPlan: "/api/v1/collection/loan/select-loan-info"
  };

  let stopRequested = false;

  const clean = v => v == null ? "" : String(v).trim().replace(/^(['"])(.*)\1$/, "$2").trim();

  function flatten(obj, prefix="", out={}) {
    if (obj && typeof obj === "object" && !Array.isArray(obj)) {
      for (const [k,v] of Object.entries(obj)) {
        const key = prefix ? `${prefix}.${k}` : k;
        if (v && typeof v === "object") flatten(v, key, out);
        else out[key] = clean(v);
      }
    } else if (Array.isArray(obj)) {
      out[prefix || "value"] = JSON.stringify(obj);
    } else out[prefix || "value"] = clean(obj);
    return out;
  }

  function emit(type, data={}) {
    chrome.runtime.sendMessage({type, ...data}).catch(()=>{});
  }

  async function getAuthHeaders() {
    try {
      // Do NOT send tabId:null. In the service worker, null becomes 0 when
      // coerced with Number(), which can return the wrong tab's auth state.
      // The content-script sender already identifies the correct tab.
      const r = await new Promise(resolve => {
        chrome.runtime.sendMessage({type:"GET_AUTH_HEADERS"}, resolve);
      });
      return (r && r.ok && r.headers) ? r.headers : {};
    } catch (_) { return {}; }
  }

  function retryDelayMs(attempt, response) {
    const retryAfter = response?.headers?.get?.("Retry-After");
    const retrySeconds = Number(retryAfter);
    if (Number.isFinite(retrySeconds) && retrySeconds >= 0) {
      return Math.min(15000, retrySeconds * 1000);
    }
    // Exponential backoff + small jitter, capped to keep the scraper usable.
    return Math.min(12000, 600 * (2 ** (attempt - 1)) + Math.floor(Math.random() * 250));
  }

  async function request(path, payload, label, retry=3) {
    let last;
    const attempts = Math.max(1, Number(retry) || 1);
    for (let attempt=1; attempt<=attempts; attempt++) {
      if (stopRequested) throw new Error("STOP_REQUESTED");
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);
      try {
        const auth = await getAuthHeaders();
        const res = await fetch(path, {
          method:"POST",
          credentials:"include",
          headers: {
            "Content-Type":"application/json",
            "Accept":"application/json, text/plain, */*",
            "Country":"ID",
            "Language":"id",
            "Tenantid": String(payload?.tenantId ?? 154),
            "Timezone":"7",
            ...auth
          },
          body: JSON.stringify(payload),
          cache:"no-store",
          signal: controller.signal
        });
        const text = await res.text();
        let data;
        try { data = JSON.parse(text); } catch (_) { data = {raw:text}; }

        if (!res.ok) {
          const detail = text && text.length < 500 ? ` - ${text.replace(/\s+/g," ").trim()}` : "";
          const err = new Error(`${label}: HTTP ${res.status}${detail}`);
          err.status = res.status;
          err.retryable = res.status === 401 || res.status === 403 || res.status === 408 || res.status === 425 ||
            res.status === 429 || res.status >= 500;
          err.response = res;
          // A 401/403 can mean the site rotated its token while this tab was
          // idle. Refresh auth from the page before the next retry.
          if ((res.status === 401 || res.status === 403) && attempt < attempts) {
            await discoverAndPublishAuth();
          }
          throw err;
        }
        return {status:res.status,data};
      } catch(e) {
        last=e;
        const retryable = e?.name === "AbortError" || e?.retryable ||
          !e?.status; // network errors are retryable
        if (attempt < attempts && retryable && !stopRequested) {
          emit("SCRAPER_STATUS", {
            level:"warn",
            message:`${label}: percobaan ${attempt}/${attempts} gagal. Mencoba lagi...`
          });
          await new Promise(r=>setTimeout(r, retryDelayMs(attempt, e?.response)));
        } else if (e?.name === "AbortError") {
          last = new Error(`${label}: timeout 30 detik`);
        }
      } finally {
        clearTimeout(timeout);
      }
    }
    throw last || new Error(`${label}: request gagal`);
  }

  function findArrays(node, out=[], path="", depth=0, seen=new Set()) {
    if (node == null || depth > 10) return out;
    if (typeof node !== "object" || seen.has(node)) return out;
    seen.add(node);
    if (Array.isArray(node)) {
      const objs=node.filter(x=>x && typeof x === "object" && !Array.isArray(x));
      if (objs.length) out.push({items:objs,path});
      for (let i=0;i<node.length && i<3;i++) findArrays(node[i],out,`${path}[${i}]`,depth+1,seen);
      return out;
    }
    for (const [k,v] of Object.entries(node)) findArrays(v,out,path?`${path}.${k}`:k,depth+1,seen);
    return out;
  }

  function recordsFrom(data) {
    // The desktop program knows the current API shape:
    // response.data = { data: [...], count, total, pageSize }
    // Keep that path first so an unrelated nested array can never be selected.
    if (data && typeof data === "object" && !Array.isArray(data)) {
      const root = data.data;
      if (Array.isArray(root)) return {records:root.filter(x=>x&&typeof x==="object"), meta:data};
      if (root && typeof root === "object" && !Array.isArray(root)) {
        for (const k of ["data","records","rows","list","items","results"]) {
          if (Array.isArray(root[k])) return {records:root[k].filter(x=>x&&typeof x==="object"), meta:root};
        }
      }
    }
    // Generic fallback for older/alternate response wrappers.
    const preferred=["data","records","rows","list","items","results","content","result","contacts","users"];
    const seen=new Set();
    function walk(node,meta,depth=0){
      if(node==null || depth>10) return null;
      if(Array.isArray(node)) return {records:node.filter(x=>x&&typeof x==="object"),meta:meta||{}};
      if(typeof node!=="object" || seen.has(node)) return null;
      seen.add(node);
      for(const k of preferred){
        if(Array.isArray(node[k])) return {records:node[k].filter(x=>x&&typeof x==="object"),meta:node};
      }
      for(const k of preferred){
        if(node[k] && typeof node[k]==="object"){
          const hit=walk(node[k],node,depth+1); if(hit && hit.records.length) return hit;
        }
      }
      const arrays=findArrays(node);
      arrays.sort((a,b)=>b.items.length-a.items.length);
      if(arrays.length) return {records:arrays[0].items,meta:node};
      return {records:[node],meta:node};
    }
    return walk(data,data,0)||{records:[],meta:{}};
  }

  function extractDataPayload(data){
    let cur=data;
    for(let i=0;i<10;i++){
      if(cur==null || typeof cur!=="object" || Array.isArray(cur)) break;
      if(Object.prototype.hasOwnProperty.call(cur,"data")) cur=cur.data;
      else if(Object.prototype.hasOwnProperty.call(cur,"result")) cur=cur.result;
      else if(Object.prototype.hasOwnProperty.call(cur,"userInfo")) cur=cur.userInfo;
      else break;
    }
    return cur;
  }

  function pick(obj, keys, fallback="") {
    if(!obj || typeof obj!=="object") return fallback;
    for(const k of keys){
      const v=obj[k];
      if(v!==undefined && v!==null && clean(v)!=="") return v;
    }
    return fallback;
  }

  function normalizeUserRecord(info, caseId, caseObj) {
    let rec=info;
    if(Array.isArray(rec)) rec=rec.find(x=>x&&typeof x==="object") || {};
    if(!rec || typeof rec!=="object") rec={};
    // Some API versions wrap the actual user object under user/info/userInfo.
    for(let i=0;i<6;i++){
      const nested=pick(rec,["user","info","userInfo","profile"],null);
      if(nested && typeof nested==="object" && !Array.isArray(nested)){ rec=nested; continue; }
      break;
    }
    const flat=flatten(rec); flat.caseId=caseId;
    const caseName=pick(caseObj,["user_name","userName","name"],"");
    const caseMobile=pick(caseObj,["mobile","mobileNumber","phone"],"");
    if(!flat["identity.userName"] && caseName) flat["identity.userName"]=clean(caseName);
    if(!flat["identity.mobileNumber"] && caseMobile) flat["identity.mobileNumber"]=clean(caseMobile);
    const cc=pick(caseObj,["caseCode","case_code"],"");
    if(!flat.caseCode && cc) flat.caseCode=clean(cc);
    return flat;
  }

  // Extract the payment summary returned by the loan-info API.
  // The endpoint may wrap the object in data/result or return an array, so
  // locate the first object that contains one or more known payment fields.
  const PAYMENT_FIELDS = [
    "caseCode","case_code","totalDueAmount","total_due_amount","totalDue","dueAmount",
    "totalPaidAmount","total_paid_amount","totalPaid","paidAmount",
    "outstandingAmount","outstanding_amount","remainingAmount","remainingDueAmount",
    "lastPaymentDate","last_payment_date","paymentDate","lastPaidDate",
    "caseStatus","case_status"
  ];

  function normalizeKey(k) {
    return String(k || "").replace(/[^a-z0-9]/gi, "").toLowerCase();
  }

  function pickPaymentValue(obj, aliases, fallback=null) {
    if (!obj || typeof obj !== "object") return fallback;
    const wanted = new Set(aliases.map(normalizeKey));
    for (const [k,v] of Object.entries(obj)) {
      if (wanted.has(normalizeKey(k)) && v !== undefined && v !== null && clean(v) !== "") return v;
    }
    return fallback;
  }

  function extractPaymentSummary(data, fallbackCaseCode="") {
    const seen = new Set();
    let best = null;
    function walk(node, depth=0) {
      if (node == null || depth > 15 || best) return;
      if (typeof node !== "object" || seen.has(node)) return;
      seen.add(node);

      if (!Array.isArray(node)) {
        const keys = Object.keys(node);
        const hits = keys.filter(k => PAYMENT_FIELDS.some(f => normalizeKey(f) === normalizeKey(k)));
        // Accept the object when it contains at least one payment amount,
        // even if caseCode/status are supplied by a parent object.
        const hasAmount = hits.some(k => [
          "totalDueAmount","total_due_amount","totalDue","dueAmount",
          "totalPaidAmount","total_paid_amount","totalPaid","paidAmount",
          "outstandingAmount","outstanding_amount","remainingAmount","remainingDueAmount"
        ].some(f => normalizeKey(f) === normalizeKey(k)));
        if (hasAmount || hits.length >= 2) {
          best = node;
          return;
        }
        // Known wrappers first, then every nested value.
        for (const key of ["data","result","repayPlan","repayPlans","repayment","repaymentPlan","plan","plans","object","response"]) {
          if (node[key] !== undefined) walk(node[key], depth + 1);
          if (best) return;
        }
        for (const value of Object.values(node)) {
          walk(value, depth + 1);
          if (best) return;
        }
        return;
      }

      for (const item of node) {
        walk(item, depth + 1);
        if (best) return;
      }
    }
    walk(data);

    const source = best || {};
    const due = excelNumber(pickPaymentValue(source, ["totalDueAmount","total_due_amount","totalDue","dueAmount"], null));
    const paid = excelNumber(pickPaymentValue(source, ["totalPaidAmount","total_paid_amount","totalPaid","paidAmount"], null));
    const outstanding = excelNumber(pickPaymentValue(source, ["outstandingAmount","outstanding_amount","remainingAmount","remainingDueAmount"], null));
    const caseCode = clean(pickPaymentValue(source, ["caseCode","case_code"], fallbackCaseCode));
    const name = clean(pickPaymentValue(source, [
      "userName","user_name","name","fullName","full_name",
      "customerName","customer_name","borrowerName","borrower_name"
    ], ""));
    // lastPaymentDate must represent the latest ACTUAL payment, not a due/schedule date.
    // Prefer explicit last-payment fields. If absent, inspect payment-history arrays
    // and choose the newest date associated with an actual paid amount/status.
    function toDateMs(v) {
      const s = clean(v); if (!s) return NaN;
      const t = Date.parse(s); return Number.isFinite(t) ? t : NaN;
    }
    function findLatestActualPaymentDate(data) {
      const explicit = [];
      const history = [];
      const seen = new Set();
      const dateKeys = ["lastPaymentDate","last_payment_date","lastPaidDate","last_paid_date","paidAt","paid_at","paymentPaidDate","payment_paid_date","transactionDate","transaction_date"];
      const amountKeys = ["paidAmount","paymentAmount","amountPaid","amount_paid","totalPaidAmount","total_paid_amount","paid_amount"];
      const historyKeys = ["payments","paymentHistory","payment_history","repayments","repaymentHistory","repayment_history","transactions","paymentList","payment_list"];
      function walk(node, depth=0, inHistory=false) {
        if (!node || typeof node !== "object" || depth > 15 || seen.has(node)) return;
        seen.add(node);
        if (Array.isArray(node)) { for (const x of node) walk(x, depth+1, true); return; }
        const hasPaidSignal = Object.keys(node).some(k => amountKeys.some(a => normalizeKey(a)===normalizeKey(k))) ||
          Object.entries(node).some(([k,v]) => /status|state/i.test(k) && /paid|success|settled|lunas|completed/i.test(clean(v)));
        for (const k of dateKeys) {
          if (Object.prototype.hasOwnProperty.call(node,k)) {
            const v=clean(node[k]); const ms=toDateMs(v); if (Number.isFinite(ms) && (inHistory || hasPaidSignal)) history.push({v,ms});
          }
        }
        for (const k of historyKeys) if (node[k] !== undefined) walk(node[k], depth+1, true);
        for (const [k,v] of Object.entries(node)) {
          if (v && typeof v === "object" && !historyKeys.includes(k)) walk(v, depth+1, inHistory);
        }
      }
      walk(data);
      history.sort((a,b)=>b.ms-a.ms);
      return history[0]?.v || "";
    }
    const explicitLast = clean(pickPaymentValue(source, [
      "lastPaymentDate","last_payment_date","lastPaidDate","last_paid_date",
      "lastRepaymentDate","last_repayment_date","lastRepayDate","last_repay_date",
      "latestPaymentDate","latest_payment_date","latestPaidDate","latest_paid_date"
    ], ""));
    const lastPaymentDate = explicitLast || findLatestActualPaymentDate(data);
    const caseStatus = clean(pickPaymentValue(source, ["caseStatus","case_status","status"], ""));
    let paymentStatus = "DATA TIDAK TERSEDIA";
    if (outstanding !== null) {
      if (outstanding > 0) paymentStatus = "BELUM LUNAS";
      else if (outstanding === 0) paymentStatus = "LUNAS";
    }
    return {
      caseCode,
      name,
      totalDueAmount: due,
      totalPaidAmount: paid,
      outstandingAmount: outstanding,
      lastPaymentDate,
      caseStatus,
      paymentStatus,
      found: Boolean(best)
    };
  }

  function isMaskedPhone(value) {
    const s = clean(value);
    return Boolean(s && (/\*/.test(s) || /x/i.test(s)));
  }

  function extractCompletePhone(data) {
    // API response can wrap the phone in data/result/object/array.
    // Walk only a small, bounded structure and prefer known phone fields.
    const PHONE_KEYS = ["phoneNumber","mobileNumber","contactPhone","phone","number","mobile"];
    const seen = new Set();
    function walk(node, depth=0) {
      if (node == null || depth > 8) return "";
      if (typeof node === "string" || typeof node === "number") {
        const v = clean(node);
        return isMaskedPhone(v) ? "" : v;
      }
      if (typeof node !== "object" || seen.has(node)) return "";
      seen.add(node);
      for (const key of PHONE_KEYS) {
        if (Object.prototype.hasOwnProperty.call(node, key)) {
          const v = clean(node[key]);
          if (v && !isMaskedPhone(v)) return v;
        }
      }
      for (const key of ["data","result","user","info","userInfo","phoneInfo","response"]) {
        if (node[key] !== undefined) {
          const hit = walk(node[key], depth + 1);
          if (hit) return hit;
        }
      }
      if (Array.isArray(node)) {
        for (const item of node.slice(0, 10)) {
          const hit = walk(item, depth + 1);
          if (hit) return hit;
        }
      }
      return "";
    }
    return walk(data);
  }

  async function completeIdentityMobile(record, caseId, caseObj, retry) {
    const current = clean(record?.["identity.mobileNumber"]);
    if (!isMaskedPhone(current)) return {record, completed:false};

    const cid = /^\d+$/.test(String(caseId)) ? Number(caseId) : caseId;
    const caseCode = clean(pick(caseObj, ["caseCode","case_code"], ""));
    const payload = {
      phoneType: "MYSELF",
      caseId: cid,
      caseCode,
      reason: "other",
      contactPhone: current,
      relationship: "R01"
    };

    try {
      const {status, data} = await requestV3(
        ENDPOINTS.completePhone,
        payload,
        `COMPLETE IDENTITY MOBILE ${caseId}`,
        retry
      );
      const full = extractCompletePhone(data);
      if (full) {
        record["identity.mobileNumber"] = full;
        record["identity.mobileNumberMasked"] = current;
        record["identity.mobileNumberComplete"] = full;
        return {record, completed:true, status, response:data, request:payload};
      }
      return {record, completed:false, status, response:data, request:payload};
    } catch (error) {
      return {record, completed:false, error:String(error), request:payload};
    }
  }

  function normalizeContactRecord(original, caseId, caseObj) {
    const c={...(original||{})};
    c.caseId=pick(c,["caseId","case_id"],caseId) || caseId;
    c.contactName=pick(c,["contactName","name","userName","contact_name","phoneName"],"");
    c.contactPhone=pick(c,["contactPhone","phone","phoneNumber","mobileNumber","contact_phone"],"");
    c.contactType=pick(c,["contactType","phoneType","contact_type","type"],"");
    c.relationship=pick(c,["relationship","relationshipCode","relation","relationCode"],"");
    c.phoneId=pick(c,["phoneId","phone_id","id"],"");
    if(!c.contactName && c.contactType!=="USER_CONTACT") c.contactName=pick(caseObj,["user_name","userName"],"");
    return c;
  }
  function csv(rows) {
    rows = rows || [];
    const keys = [...new Set(rows.flatMap(r => Object.keys(r || {})))];
    if (!keys.length) return "data\r\n";
    const esc = v => {
      if (v == null) return "";
      let s = typeof v === "object" ? JSON.stringify(v) : String(v);
      return /[",\r\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
    };
    return "\uFEFF" + [keys.map(esc).join(","), ...rows.map(r => keys.map(k=>esc(r?.[k])).join(","))].join("\r\n");
  }

  function stamp() {
    const d=new Date(), p=n=>String(n).padStart(2,"0");
    return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  }

  async function download(name, text, mime="text/plain") {
    const blob = new Blob([text], {type:mime});
    const url = URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download=name; a.style.display="none";
    document.documentElement.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 3000);
  }


  // ===== Excel XLSX export (template-compatible multi-sheet workbook) =====
  const CASE_COLUMNS = [
    "_case_id","agency_name","app_name","borrow_type","casePendingReplyFlag",
    "casePromiseRepaymentFlag","case_code","case_status","collector_name",
    "credit_type","due_date","group_name","hasCollectionLog","id",
    "last_user_reach_at","loan_amount","mobile","outstanding_amount",
    "overdue_days","overdue_installments","product_name","product_type",
    "queue_code","system_name","team_name","total_installments",
    "user_name","waived_amount"
  ];
  const CONTACT_COLUMNS = ["caseId","contactName","contactPhone","contactType","Nama CH","DPD","Ammount"];
  const USER_COLUMNS = [
    "caseId","bank.accountNumber","bank.bankName","bank.disbursementChannel",
    "employment.companyName","employment.companyPhone","employment.incomeRange",
    "employment.jobTitle","employment.workAddress","identity.address",
    "identity.birthDate","identity.educationLevel","identity.email",
    "identity.gender","identity.maritalStatus","identity.mobileNumber",
    "identity.userName","phoneType","userPic.livePhoto"
  ];
  const INFO_ROWS = [
    ["Fitur","Keterangan"],
    ["Scraper","Case + User Info + Contact + Complete Phone + Payment Recap"],
    ["Format Excel","DATA SIMPLE + REKAP PEMBAYARAN + DATA NASABAH + EMERGENCY CONTACT + DATA CASE MENTAH"],
    ["SMS","Dihapus dari aplikasi"],
    ["Authentication","Bearer Token"],
    ["Output","Excel + audit sheets + automatic Chrome download"],
    ["Retry","Configurable with retry-safe delays"],
    ["Audit","Request/error log + completeness status"],
    ["Integrity","COMPLETE / PARTIAL / STOPPED status"]
  ];

  // Excel cell text limit is 32,767 UTF-16 code units.
  // Keep a safety margin because the RAW JSON sheets can contain very large responses.
  const EXCEL_TEXT_LIMIT = 30000;

  function cleanXmlText(value) {
    return String(value ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, "");
  }

  const xmlEsc = v => cleanXmlText(v)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;").replace(/\'/g,"&apos;");

  // Convert monetary values such as 622000, "622000", "622.000",
  // "1.234.567,89" or "Rp 1.234.567" into a real JavaScript number.
  // This is used only for monetary/DPD columns; phone numbers and IDs remain text.
  function excelNumber(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (value == null || value === "") return null;
    let s = String(value).trim().replace(/\s/g, "").replace(/^Rp\.?/i, "");
    if (!s) return null;
    s = s.replace(/[^0-9,.-]/g, "");
    if (!s || !/[0-9]/.test(s)) return null;

    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");
    if (lastComma >= 0 && lastDot >= 0) {
      // The last separator is treated as the decimal separator.
      if (lastComma > lastDot) s = s.replace(/\./g, "").replace(",", ".");
      else s = s.replace(/,/g, "");
    } else if (lastComma >= 0) {
      const decimals = s.length - lastComma - 1;
      // Indonesian thousands: 1.234.567 is handled above; for a lone comma,
      // 3 digits after it means thousands, otherwise decimal.
      if (decimals === 3 && lastComma > 0) s = s.replace(/,/g, "");
      else s = s.replace(",", ".");
    } else if ((s.match(/\./g) || []).length > 1) {
      s = s.replace(/\./g, "");
    } else if (lastDot >= 0) {
      const decimals = s.length - lastDot - 1;
      if (decimals === 3 && lastDot > 0) s = s.replace(/\./g, "");
    }
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function excelCell(v, styleId=0) {
    // Explicit numeric cells are written without t="inlineStr", which makes
    // Excel recognize them as numbers and enables Largest/Smallest sorting.
    if (v && typeof v === "object" && v.__excelNumber === true) {
      const n = excelNumber(v.value);
      return n == null ? `<c s="${styleId}"/>` : `<c s="${styleId}"><v>${String(n)}</v></c>`;
    }

    // Real Excel date/time serial. The cell remains numeric so Excel's
    // Largest/Smallest filters work chronologically. Style 3 applies the
    // DD/MM/YYYY HH:mm:ss number format.
    if (v && typeof v === "object" && v.__excelDate === true) {
      const n = Number(v.value);
      return Number.isFinite(n) ? `<c s="${styleId}"><v>${String(n)}</v></c>` : `<c s="${styleId}"/>`;
    }

    // Formula cell with an optional cached numeric result. The cached value
    // is important for Excel sorting/filtering immediately after export: the
    // AMOUNT column remains a real number even before Excel recalculates.
    if (v && typeof v === "object" && v.__excelFormula === true) {
      const formula = cleanXmlText(v.formula);
      const cached = excelNumber(v.cachedValue);
      if (cached != null) {
        return `<c s="${styleId}"><f>${xmlEsc(formula)}</f><v>${String(cached)}</v></c>`;
      }
      return `<c s="${styleId}"><f>${xmlEsc(formula)}</f><v></v></c>`;
    }

    const s = typeof v === "object" && v !== null ? JSON.stringify(v) : String(v ?? "");
    if (!s) return `<c s="${styleId}"/>`;

    // Support real Excel formulas. Values beginning with "=" are written as
    // formula cells instead of literal text, so the exported DATA SIMPLE sheet
    // behaves like the supplied Excel template.
    if (typeof v === "string" && /^=/.test(v)) {
      const formula = cleanXmlText(v.slice(1));
      return `<c s="${styleId}"><f>${xmlEsc(formula)}</f></c>`;
    }

    const safe = cleanXmlText(s);
    return `<c s="${styleId}" t="inlineStr"><is><t xml:space="preserve">${xmlEsc(safe)}</t></is></c>`;
  }

  function amountCell(value) {
    return {__excelNumber:true, value};
  }

  function formulaNumberCell(formula, cachedValue) {
    return {__excelFormula:true, formula, cachedValue};
  }

  // Normalize payment timestamps into a human-readable Indonesian date + time.
  // The API may return Unix seconds, Unix milliseconds, ISO strings, or
  // already-formatted dates. The export must never expose raw values such as
  // 1785676641000 in the "TANGGAL PEMBAYARAN TERAKHIR" column.
  function formatPaymentDate(value) {
    const x = clean(value);
    if (!x) return "";

    let d = null;
    if (/^\d{10,16}$/.test(x)) {
      const n = Number(x);
      if (Number.isFinite(n)) {
        // 10 digits are normally Unix seconds; 11+ are Unix milliseconds.
        d = new Date(x.length <= 10 ? n * 1000 : n);
      }
    } else {
      // Handle common API date formats, including ISO timestamps and the
      // Indonesian display format DD/MM/YYYY HH:mm:ss. Parsing the latter
      // explicitly avoids browser locale ambiguity (MM/DD vs DD/MM).
      let m = x.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/);
      if (m) {
        const [,dd,mm,yyyy,hh="00",mi="00",ss="00"] = m;
        const candidate = new Date(Date.UTC(Number(yyyy), Number(mm)-1, Number(dd), Number(hh), Number(mi), Number(ss)));
        if (candidate.getUTCFullYear()===Number(yyyy) && candidate.getUTCMonth()===Number(mm)-1 && candidate.getUTCDate()===Number(dd)) d = candidate;
      }
      if (!d) {
        const parsed = new Date(x);
        if (Number.isFinite(parsed.getTime())) d = parsed;
      }
    }

    // Never return an arbitrary text value in this column. A single text cell
    // mixed with numeric date serials can make Excel treat the whole filter as
    // a text field and hide the chronological sort options.
    if (!d || !Number.isFinite(d.getTime())) return "";
    // Build the value manually so Indonesian locale punctuation does not
    // turn the time separators (:) into slashes.
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Asia/Jakarta",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).formatToParts(d);
    const get = type => parts.find(part => part.type === type)?.value || "";
    const day = Number(get("day"));
    const month = Number(get("month"));
    const year = Number(get("year"));
    const hour = Number(get("hour"));
    const minute = Number(get("minute"));
    const second = Number(get("second"));

    // Store the payment date as a REAL Excel date/time serial, not as text.
    // This is important because Excel can then sort/filter the column by
    // Smallest -> Largest and Largest -> Smallest chronologically.
    // The displayed value is still DD/MM/YYYY HH:mm:ss (WIB).
    const excelSerial = (Date.UTC(year, month - 1, day, hour, minute, second) / 86400000) + 25569;
    return {__excelDate:true, value:excelSerial};
  }

  function normalizeRowsForExcel(rows) {
    // Any string over the Excel limit is split into continuation rows.
    // This prevents Excel's "Repaired Records: String properties" warning
    // while preserving the complete JSON/text in the workbook.
    const out = [];
    for (const row of (rows || [])) {
      const normalized = Array.isArray(row) ? row.slice() : [row];
      let chunks = null;
      for (let i=0; i<normalized.length; i++) {
        if (typeof normalized[i] !== "string") continue;
        const value = normalized[i];
        if (value.length > EXCEL_TEXT_LIMIT) {
          chunks = [];
          for (let p=0; p<value.length; p += EXCEL_TEXT_LIMIT) chunks.push(value.slice(p,p+EXCEL_TEXT_LIMIT));
          break;
        }
      }
      if (!chunks) { out.push(normalized); continue; }
      // Put the first chunk in the original column and continuation chunks
      // in additional rows with the same leading identifiers.
      const targetIndex = normalized.findIndex(v => typeof v === "string" && v.length > EXCEL_TEXT_LIMIT);
      chunks.forEach((chunk, idx) => {
        const r = normalized.slice();
        r[targetIndex] = chunk;
        if (idx > 0 && r.length > 0) r[0] = `${r[0] ?? ""} (cont. ${idx+1})`;
        out.push(r);
      });
    }
    return out;
  }

  function sheetXml(rows, widths=[], autoFilter=true, numberCols=[], freezeCell="A2", showGridLines=true) {
    rows = normalizeRowsForExcel(rows || []);
    const maxCols = Math.max(1, ...rows.map(r => r.length));
    const colLetter = n => {
      let s="";
      while(n){ const m=(n-1)%26; s=String.fromCharCode(65+m)+s; n=Math.floor((n-1)/26); }
      return s;
    };
    let cols = "";
    if (widths.length) {
      cols = `<cols>${widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${Number(w)||12}" customWidth="1"/>`).join("")}</cols>`;
    }
    const body = rows.map((r,ri) => {
      const vals = Array.from({length:maxCols},(_,i)=>r[i] ?? "");
      return `<row r="${ri+1}">${vals.map((v,i)=>excelCell(v, (numberCols && typeof numberCols === "object" && !Array.isArray(numberCols) ? (numberCols[i+1] ?? 0) : (numberCols.includes(i+1) ? 1 : 0)))).join("")}</row>`;
    }).join("");
    const filter = autoFilter && rows.length
      ? `<autoFilter ref="A1:${colLetter(maxCols)}${rows.length}"/>` : "";
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView showGridLines="${showGridLines ? "1" : "0"}" workbookViewId="0"><pane ySplit="1" topLeftCell="${freezeCell}" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="${freezeCell}" sqref="${freezeCell}"/></sheetView></sheetViews>
${cols}<sheetData>${body}</sheetData>${filter}</worksheet>`;
  }

  function crc32(bytes) {
    let table = crc32._table;
    if (!table) {
      table = crc32._table = new Uint32Array(256);
      for(let n=0;n<256;n++){
        let c=n;
        for(let k=0;k<8;k++) c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);
        table[n]=c>>>0;
      }
    }
    let c=0xFFFFFFFF;
    for(const b of bytes) c=table[(c^b)&255]^(c>>>8);
    return (c^0xFFFFFFFF)>>>0;
  }

  function u16(n){ return new Uint8Array([n&255,(n>>>8)&255]); }
  function u32(n){ return new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]); }
  function concatBytes(parts) {
    const total=parts.reduce((n,a)=>n+a.length,0), out=new Uint8Array(total);
    let p=0; for(const a of parts){out.set(a,p);p+=a.length;} return out;
  }

  // Minimal ZIP writer using "stored" entries. Excel accepts this valid XLSX container.
  function makeZip(entries) {
    const local=[], central=[]; let offset=0;
    const enc=new TextEncoder();
    for(const [name,text] of entries){
      const nb=enc.encode(name), data=enc.encode(text), crc=crc32(data);
      const lh=concatBytes([
        u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(0),
        u32(crc),u32(data.length),u32(data.length),u16(nb.length),u16(0),nb,data
      ]);
      local.push(lh);
      const ch=concatBytes([
        u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(0),
        u32(crc),u32(data.length),u32(data.length),u16(nb.length),u16(0),
        u16(0),u16(0),u16(0),u32(0),u32(offset),nb
      ]);
      central.push(ch); offset+=lh.length;
    }
    const centralBytes=concatBytes(central), localBytes=concatBytes(local);
    const end=concatBytes([
      u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),
      u32(centralBytes.length),u32(localBytes.length),u16(0)
    ]);
    return concatBytes([localBytes,centralBytes,end]);
  }

  function buildXlsx(sheets) {
    const esc = xmlEsc;
    const workbookSheets = sheets.map((s,i)=>`<sheet name="${esc(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join("");
    const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>${workbookSheets}</sheets></workbook>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join("")}
<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;
    const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
${sheets.map((s,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;
    const styles=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="dd/mm/yyyy hh:mm:ss"/></numFmts><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0"/><xf numFmtId="1" fontId="0" fillId="0" borderId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/></cellXfs>
</styleSheet>`;
    const entries=[
      ["[Content_Types].xml",ct],
      ["_rels/.rels",rootRels],
      ["xl/workbook.xml",workbook],
      ["xl/_rels/workbook.xml.rels",rels],
      ["xl/styles.xml",styles]
    ];
    sheets.forEach((s,i)=>entries.push([`xl/worksheets/sheet${i+1}.xml`,sheetXml(s.rows,s.widths,s.autoFilter!==false,s.numberCols||[],s.freezeCell||"A2",s.showGridLines!==false)]));
    return makeZip(entries);
  }

  function rowFrom(obj, columns) {
    return columns.map(k => obj?.[k] == null ? "" : obj[k]);
  }

  function bytesToBase64(bytes){
    const arr=bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let binary="";
    const chunk=0x8000;
    for(let i=0;i<arr.length;i+=chunk) binary+=String.fromCharCode(...arr.subarray(i,i+chunk));
    return btoa(binary);
  }

  async function downloadXlsx(filename, sheets) {
    const bytes=buildXlsx(sheets);
    const base64=bytesToBase64(bytes);
    // Prefer the downloads API through the service worker so the report is
    // registered by Chrome's download manager and does not depend on a DOM click.
    if(base64.length<=45_000_000){
      const result=await new Promise(resolve=>chrome.runtime.sendMessage({
        type:"DOWNLOAD_BINARY", filename, base64,
        mime:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      },resolve));
      if(result?.ok) return result;
    }
    // Fallback for unusually large files.
    const blob=new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download=filename; a.style.display="none";
    document.documentElement.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),5000);
    return {ok:true,fallback:true};
  }

  // ========================= V3 JOB ENGINE =========================
  // V3 keeps the existing API contract/export format, but adds:
  // - global request semaphore + rate limiting
  // - abort-all stop handling
  // - bounded worker pool for case details
  // - parallel User/Payment/Contact requests per case
  // - compact per-case audit records

  const activeControllers = new Set();
  let runActive = false;

  class RequestGate {
    constructor(limit=6, minIntervalMs=0) {
      this.limit=Math.max(1,Number(limit)||1);
      this.minIntervalMs=Math.max(0,Number(minIntervalMs)||0);
      this.active=0; this.queue=[]; this.lastStart=0;
    }
    async acquire() {
      if (this.active < this.limit && Date.now()-this.lastStart >= this.minIntervalMs) {
        this.active++; this.lastStart=Date.now(); return;
      }
      await new Promise(resolve=>this.queue.push(resolve));
      this.active++; this.lastStart=Date.now();
    }
    release() {
      this.active=Math.max(0,this.active-1);
      if (!this.queue.length || this.active>=this.limit) return;
      const wait=Math.max(0,this.minIntervalMs-(Date.now()-this.lastStart));
      setTimeout(()=>{
        const next=this.queue.shift();
        if(next) next();
      },wait);
    }
    clear() { this.queue.splice(0).forEach(r=>r()); }
  }

  let requestGate = new RequestGate(16, 0);

  function abortAllRequests(){
    for(const controller of activeControllers){ try{controller.abort();}catch(_){} }
    activeControllers.clear();
    requestGate.clear();
  }

  function sleep(ms){ return new Promise(r=>setTimeout(r,Math.max(0,ms))); }

  function stableOptions(opts={}){
    return {
      tenantId:Number(opts.tenantId||154), pageSize:Math.max(1,Number(opts.pageSize||100)),
      maxPages:Math.max(0,Number(opts.maxPages||0)), retry:Math.max(1,Number(opts.retry||3)),
      concurrency:Math.min(16,Math.max(1,Number(opts.concurrency||12))),
      requestConcurrency:Math.min(24,Math.max(1,Number(opts.requestConcurrency||16))),
      requestInterval:Math.min(2000,Math.max(0,Number(opts.requestInterval||0))),
      phoneConcurrency:Math.min(6,Math.max(1,Number(opts.phoneConcurrency||3))),
      includePaymentRecap:opts.includePaymentRecap!==false
    };
  }

  async function requestV3(path,payload,label,retry=3){
    let last;
    const attempts=Math.max(1,Number(retry)||1);
    for(let attempt=1;attempt<=attempts;attempt++){
      if(stopRequested) throw new Error("STOP_REQUESTED");
      await requestGate.acquire();
      if(stopRequested){ requestGate.release(); throw new Error("STOP_REQUESTED"); }
      const controller=new AbortController(); activeControllers.add(controller);
      const timeout=setTimeout(()=>controller.abort(),30000);
      try{
        const auth=await getAuthHeaders();
        const res=await fetch(path,{method:"POST",credentials:"include",headers:{
          "Content-Type":"application/json","Accept":"application/json, text/plain, */*",
          "Country":"ID","Language":"id","Tenantid":String(payload?.tenantId??154),"Timezone":"7",...auth
        },body:JSON.stringify(payload),cache:"no-store",signal:controller.signal});
        const text=await res.text(); let data;
        try{data=JSON.parse(text)}catch(_){data={raw:text}};
        if(!res.ok){
          const detail=text&&text.length<500?` - ${text.replace(/\s+/g," ").trim()}`:"";
          const e=new Error(`${label}: HTTP ${res.status}${detail}`);e.status=res.status;e.response=res;
          e.retryable=res.status===408||res.status===425||res.status===429||res.status>=500;throw e;
        }
        return {status:res.status,data};
      }catch(e){
        last=e;
        const retryable=e?.name==="AbortError"||e?.retryable||!e?.status;
        if(attempt<attempts&&retryable&&!stopRequested){
          emit("SCRAPER_STATUS",{level:"warn",message:`${label}: retry ${attempt}/${attempts}...`});
          await sleep(retryDelayMs(attempt,e?.response));
        }else if(e?.name==="AbortError" && !stopRequested){last=new Error(`${label}: timeout 30 detik`)}
      }finally{
        clearTimeout(timeout);activeControllers.delete(controller);requestGate.release();
      }
    }
    throw last||new Error(`${label}: request gagal`);
  }

  function casePagePayload(page, pageSize, tenantId){
    // Different builds of the CCO API have used different pagination keys.
    // Send the same page through the common aliases so Page Size 100 can
    // actually advance to page 2, 3, ... instead of returning page 1 again.
    const offset=(page-1)*pageSize;
    return {
      page, pageNo:page, pageNum:page, pageIndex:page, currentPage:page,
      pageSize, limit:pageSize, offset,
      tenantId, scene:"collector_case_detail"
    };
  }

  function paginationMeta(data){
    // Look through the response wrappers for pagination metadata.
    const seen=new Set();
    const keys=["totalPages","pageCount","totalPage","pages","lastPage","total_page","page_count"];
    const totalKeys=["total","totalCount","totalRecords","recordCount","count"];
    const queue=[data];
    let best={};
    while(queue.length){
      const node=queue.shift();
      if(!node || typeof node!=="object" || seen.has(node)) continue;
      seen.add(node);
      if(Array.isArray(node)) continue;
      for(const k of keys){
        const v=Number(node[k]);
        if(Number.isFinite(v) && v>0 && best.pages==null) best.pages=v;
      }
      for(const k of totalKeys){
        const v=Number(node[k]);
        if(Number.isFinite(v) && v>=0 && best.total==null) best.total=v;
      }
      for(const v of Object.values(node)) if(v && typeof v==="object") queue.push(v);
    }
    return best;
  }

  async function fetchCaseListing(opts){
    const pageSize=opts.pageSize,maxPages=opts.maxPages,retry=opts.retry,tenantId=opts.tenantId;
    const cases=new Map();
    emit("SCRAPER_STATUS",{level:"info",message:"V3: mengambil daftar Case..."});

    // IMPORTANT:
    // This CCO endpoint behaves like a LIMIT endpoint in the current build.
    // When pageSize=100 it returns only 100 rows, while the backend does not
    // reliably honor page/pageNo/offset for the listing endpoint. The fact
    // that pageSize=999999 returns the complete dataset confirms that behavior.
    //
    // Therefore:
    //   maxPages = 0  => ALL mode: keep the user's UI Page Size (100), but use
    //                    a large API fetch size so the backend returns all rows.
    //   maxPages > 0  => normal paged mode using the requested Page Size.
    //
    // This separates the UI/batch setting from the backend's fetch LIMIT and
    // prevents ALL mode from being accidentally capped at the first 100 rows.
    if(maxPages===0){
      const ALL_API_PAGE_SIZE=999999;
      emit("SCRAPER_STATUS",{
        level:"info",
        message:`Mode ALL aktif: mengambil seluruh Case (API limit ${ALL_API_PAGE_SIZE.toLocaleString("id-ID")})...`
      });

      const payload={
        page:1, pageNo:1, pageNum:1, pageIndex:1, currentPage:1,
        pageSize:ALL_API_PAGE_SIZE,
        limit:ALL_API_PAGE_SIZE,
        size:ALL_API_PAGE_SIZE,
        offset:0,
        tenantId, scene:"collector_case_detail"
      };
      const {data}=await requestV3(ENDPOINTS.cases,payload,"CASE ALL",retry);
      const parsed=recordsFrom(data);
      const records=parsed.records||[];

      for(const obj of records){
        const id=clean(obj?.id??obj?.caseId??obj?.case_id);
        if(id) cases.set(id,obj);
      }

      emit("SCRAPER_PROGRESS",{
        phase:"CASE",
        page:1,
        records:records.length,
        added:cases.size,
        total:cases.size,
        totalPages:1,
        allMode:true
      });

      if(records.length>=ALL_API_PAGE_SIZE){
        emit("SCRAPER_STATUS",{
          level:"warn",
          message:"Dataset mencapai batas ALL API. Coba lagi dengan batas API yang lebih tinggi jika jumlah data melebihi 999.999."
        });
      }
      return {caseItems:[...cases.entries()],missingRequested:[]};
    }

    // Bounded mode: maxPages > 0. Keep Page Size as the API page size.
    let page=1;
    const safetyLimit=maxPages;
    let discoveredPages=null;
    let previousTotal=-1;

    while(!stopRequested && page<=safetyLimit){
      const payload=casePagePayload(page,pageSize,tenantId);
      const {data}=await requestV3(ENDPOINTS.cases,payload,`CASE PAGE ${page}`,retry);
      const parsed=recordsFrom(data);
      const records=parsed.records||[];
      const pmeta=paginationMeta(data);

      if(pmeta.pages!=null) discoveredPages=pmeta.pages;
      else if(pmeta.total!=null && pmeta.total>pageSize){
        discoveredPages=Math.ceil(pmeta.total/pageSize);
      }

      let added=0;
      for(const obj of records){
        const id=clean(obj?.id??obj?.caseId??obj?.case_id);
        if(id && !cases.has(id)){cases.set(id,obj);added++;}
      }

      emit("SCRAPER_PROGRESS",{
        phase:"CASE", page, records:records.length, added,
        total:cases.size,
        totalPages:Math.min(discoveredPages||safetyLimit,safetyLimit)
      });

      if(stopRequested) break;
      if(page>=safetyLimit) break;
      if(discoveredPages!=null && page>=discoveredPages) break;
      if(records.length===0) break;
      if(records.length<pageSize) break;

      // If the backend ignores page/offset and returns page 1 repeatedly,
      // don't loop forever. In ALL mode this branch is never used.
      if(page>1 && added===0 && cases.size===previousTotal) break;
      previousTotal=cases.size;
      page++;
    }

    return {caseItems:[...cases.entries()],missingRequested:[]};
  }

  const valueByLeafKey=(o,keys)=>{
    const wanted=new Set(keys.map(x=>String(x).toLowerCase()));
    for(const [k,v] of Object.entries(flatten(o||{}))){if(wanted.has(k.split(".").pop().toLowerCase())&&clean(v)!=="")return v}
    return "";
  };

  async function completeContactPhones(list,caseId,obj,opts){
    let next=0;
    const worker=async()=>{
      while(!stopRequested){
        const i=next++;if(i>=list.length)break;
        const c=list[i],masked=clean(c.contactPhone);
        const caseCode=clean(c.caseCode??obj?.caseCode??obj?.case_code);
        const phoneType=clean(c.phoneType??c.contactPhoneType??c.contactType??"MYSELF");
        const relationship=clean(c.relationship??c.relationshipCode??c.relation??"R01");
        const phoneId=(phoneType==="USER_CONTACT")?(c.phoneId??c.id):null;
        const payload={phoneType,caseId:/^\d+$/.test(String(caseId))?Number(caseId):caseId,caseCode,reason:clean(c.reason||"other"),contactPhone:masked,relationship};
        if(phoneId!=null&&String(phoneId).trim())payload.phoneId=phoneId;
        const maskedFlag=Boolean(masked&&(/[ *]/.test(masked)||/x/i.test(masked)));
        if(maskedFlag&&(phoneType!=="USER_CONTACT"||phoneId!=null)){
          try{
            const {status,data}=await requestV3(ENDPOINTS.completePhone,payload,`COMPLETE PHONE ${caseId}`,opts.retry);
            const full=clean(pick(data,["data","phone","phoneNumber","contactPhone","mobileNumber"],""));
            if(full){c.contactPhoneComplete=full;c.contactPhoneFull=full;c.contactPhone=full;c.phoneMasked=masked}else{c.contactPhoneComplete="";c.contactPhoneFull="";c.phoneMasked=masked}
            c.__completeMeta={status};
          }catch(e){c.contactPhoneComplete="";c.contactPhoneFull="";c.phoneMasked=masked;c.__error=String(e)}
        }else if(masked){c.contactPhoneComplete=masked;c.contactPhoneFull=masked;c.phoneMasked=masked}
      }
    };
    await Promise.all(Array.from({length:Math.min(opts.phoneConcurrency,Math.max(1,list.length))},worker));
  }

  async function processCase(caseId,obj,opts){
    const cid=/^\d+$/.test(String(caseId))?Number(caseId):caseId;
    // Privacy: user/emergency contacts are intentionally NOT scraped.
    const result={caseId,caseObj:obj,userRows:[],contacts:[],payment:null,status:"BERHASIL",userStatus:"PENDING",contactStatus:"SKIPPED",paymentStatus:"SKIPPED",error:"",contactCount:0};
    const [userRes,paymentRes]=await Promise.allSettled([
      requestV3(ENDPOINTS.user,{caseId:cid},`USER INFO ${caseId}`,opts.retry),
      opts.includePaymentRecap ? requestV3(ENDPOINTS.repayPlan,{caseId:cid},`PAYMENT ${caseId}`,opts.retry) : Promise.resolve(null)
    ]);

    if(userRes.status==="fulfilled"){
      result.userStatus="BERHASIL";
      const info=extractDataPayload(userRes.value.data),recs=recordsFrom(info).records;
      const source=recs.length?recs:[info];
      for(const rec of source){
        const userRecord=normalizeUserRecord(rec,caseId,obj);
        const completed=await completeIdentityMobile(userRecord,caseId,obj,opts.retry);
        result.userRows.push(completed.record);
      }
      if(!result.userRows.length)result.userRows.push(normalizeUserRecord({},caseId,obj));
    }else{
      result.userStatus="ERROR";result.error=String(userRes.reason?.message||userRes.reason||"");
      result.userRows.push(normalizeUserRecord({},caseId,obj));
    }

    if(paymentRes.status==="fulfilled"&&paymentRes.value){
      result.payment=extractPaymentSummary(paymentRes.value.data,clean(obj?.caseCode??obj?.case_code));
      if(!result.payment.caseCode)result.payment.caseCode=clean(obj?.caseCode??obj?.case_code);
      result.paymentStatus=result.payment.found?"BERHASIL":"DATA TIDAK LENGKAP";
    }else if(opts.includePaymentRecap){
      result.paymentStatus="ERROR";result.payment={caseCode:clean(obj?.caseCode??obj?.case_code),totalDueAmount:null,totalPaidAmount:null,outstandingAmount:null,lastPaymentDate:"",caseStatus:"",paymentStatus:"DATA TIDAK TERSEDIA",found:false,error:String(paymentRes.reason?.message||paymentRes.reason||"")};
    }

    // No contact endpoint is called and no contact data is exported.
    if(result.userStatus==="ERROR"||result.paymentStatus==="ERROR")result.status="PARTIAL";
    return result;
  }

  async function exportMainV3(caseItems,results,opts,missingRequested,stopped){
    const users=results.flatMap(r=>r.userRows||[]);
    const payments=new Map(results.filter(r=>r.payment).map(r=>[clean(r.caseId),r.payment]));
    const summary=results.map(r=>({caseId:r.caseId,status:r.status==="PARTIAL"?"PARTIAL":"BERHASIL"}));
    const caseById=new Map(caseItems.map(([id,o])=>[clean(id),flatten(o)]));
    const userByCase=new Map();for(const u of users){const cid=clean(u.caseId);if(cid&&!userByCase.has(cid))userByCase.set(cid,u)}
    const nameByCase=new Map();for(const [cid,u] of userByCase){const nm=clean(u["identity.userName"]??u.userName);if(cid&&nm)nameByCase.set(cid,nm)}

    const caseRows=[CASE_COLUMNS,...caseItems.map(([id,o])=>{const flat=flatten(o);flat._case_id=id;const row=rowFrom(flat,CASE_COLUMNS);[16,18,19,20].forEach(idx=>row[idx-1]=amountCell(row[idx-1]));return row})];
    const userRows=[USER_COLUMNS,...caseItems.map(([id])=>rowFrom(userByCase.get(clean(id))||{},USER_COLUMNS))];

    const paymentRows=[["CASE ID","CASE CODE","NAMA","DPD","TOTAL TAGIHAN","TOTAL PEMBAYARAN","SISA TAGIHAN","TANGGAL PEMBAYARAN TERAKHIR","STATUS PEMBAYARAN","CASE STATUS"],...caseItems.map(([id,obj])=>{const p=payments.get(clean(id))||{},u=userByCase.get(clean(id))||{};const name=clean(p.name||valueByLeafKey(u,["userName","name","fullName","customerName","borrowerName"])||valueByLeafKey(obj,["userName","user_name","name","fullName","customerName","borrowerName"]));const dpd=valueByLeafKey(obj,["overdue_days","overdueDays","dpd","dpdDays","daysOverdue","days_overdue"])||valueByLeafKey(u,["overdue_days","overdueDays","dpd","dpdDays","daysOverdue","days_overdue"]);return[id,p.caseCode||clean(obj?.caseCode??obj?.case_code),name,excelNumber(dpd)??"",amountCell(p.totalDueAmount),amountCell(p.totalPaidAmount),amountCell(p.outstandingAmount),formatPaymentDate(p.lastPaymentDate),p.paymentStatus||"DATA TIDAK TERSEDIA",p.caseStatus||""]})];

    const auditRows=[["CASE ID","STATUS","USER","PAYMENT","ERROR"],...caseItems.map(([id])=>{const r=results.find(x=>clean(x.caseId)===clean(id))||{};return[id,r.status||"PENDING",r.userStatus||"",r.paymentStatus||"",r.error||""]})];
    const simpleHeader=["CASE ID","LOAN ID","NAME","PHONE","EMAIL","AMOUNT","DPD","ALAMAT","TEMPAT KERJA","NOMOR KANTOR","PENGHASILAN CH","BANK PENCAIRAN"];
    const simpleRows=[simpleHeader,...caseItems.map(([id],idx)=>{const r=idx+2;const c=caseById.get(clean(id))||{};return[`='DATA NASABAH'!A${r}`,`=VLOOKUP(A${r},'DATA CASE MENTAH'!A:G,7,0)`,`='DATA NASABAH'!Q${r}`,`=VLOOKUP(A${r},'DATA NASABAH'!A:P,16,0)`,`=VLOOKUP(A${r},'DATA NASABAH'!A:M,13,0)`,formulaNumberCell(`VLOOKUP(A${r},'DATA CASE MENTAH'!A:T,18,0)`,excelNumber(c.outstanding_amount)),formulaNumberCell(`VLOOKUP(A${r},'DATA CASE MENTAH'!A:S,19,0)`,excelNumber(c.overdue_days)),`=VLOOKUP(A${r},'DATA NASABAH'!A:J,10,0)`,`=VLOOKUP(A${r},'DATA NASABAH'!A:E,5,0)`,`=VLOOKUP(A${r},'DATA NASABAH'!A:F,6,0)`,`=VLOOKUP(A${r},'DATA NASABAH'!A:G,7,0)`,`=VLOOKUP(A${r},'DATA NASABAH'!A:D,3,0)`]})];

    const folder=`SCRAPER_${new Date().toISOString().slice(0,10)}.xlsx`;
    const sheets=[
      {name:"DATA SIMPLE",rows:simpleRows,widths:[14,16,28,18,30,18,10,45,28,20,24,13],numberCols:{6:1,7:2},freezeCell:"A2",showGridLines:true},
      ...(opts.includePaymentRecap!==false?[{name:"REKAP PEMBAYARAN",rows:paymentRows,widths:[14,24,30,10,18,20,18,30,24,20],numberCols:{4:2,5:2,6:2,7:2,8:3},freezeCell:"A2",showGridLines:true}]:[]),
      {name:"DATA NASABAH",rows:userRows,widths:[14,20,15,26,24,25,24,21,24,18,13,22,30,18,22,20,22,14,120],numberCols:{},freezeCell:"A5",showGridLines:true},
      {name:"DATA CASE MENTAH",rows:caseRows,widths:[14,13,13,13,22,26,14,13,16,14,13,13,18,14,20,16,18,20,14,22,30,16,14,13,16,20,13,13],numberCols:{16:1,18:1,19:2,20:2},freezeCell:"A2",showGridLines:true},
      {name:"AUDIT V3",rows:auditRows,widths:[16,14,14,14,18,16,70],numberCols:{6:1},freezeCell:"A2",showGridLines:true}
    ];
    await downloadXlsx(`${folder}.xlsx`,sheets);
    return {folder,xlsx:`${folder}.xlsx`,users:users.length,contacts:0,payments:payments.size,summary,auditStatus:stopped?"STOPPED":(missingRequested.length||results.some(r=>r.status!=="BERHASIL")?"PARTIAL":"COMPLETE")};
  }

  async function run(opts={}){
    if(runActive){emit("SCRAPER_STATUS",{level:"warn",message:"Job V3 masih berjalan."});return}
    runActive=true;stopRequested=false;activeControllers.clear();
    opts=stableOptions(opts);requestGate=new RequestGate(opts.requestConcurrency,opts.requestInterval);
    let results=[];
    try{
      const {caseItems,missingRequested}=await fetchCaseListing(opts);
      let next=0;let completed=0;
      const worker=async()=>{
        while(!stopRequested){
          const i=next++;
          if(i>=caseItems.length)break;
          const [caseId,obj]=caseItems[i];
          let result;
          try{
            result=await processCase(caseId,obj,opts);
          }catch(e){
            result={caseId,caseObj:obj,userRows:[],contacts:[],payment:null,status:"PARTIAL",userStatus:"ERROR",contactStatus:"SKIPPED",paymentStatus:opts.includePaymentRecap?"ERROR":"SKIPPED",error:String(e?.message||e),contactCount:0};
          }
          results.push(result);completed++;
          emit("SCRAPER_PROGRESS",{
            phase:"CASE_DETAIL",index:completed,total:caseItems.length,caseId,
            users:results.reduce((n,r)=>n+(r.userRows?.length||0),0),
            contacts:0
          });
        }
      };
      await Promise.all(Array.from({length:Math.min(opts.concurrency,Math.max(1,caseItems.length))},worker));
      const exportInfo=await exportMainV3(caseItems,results,opts,missingRequested,stopRequested);
      emit("SCRAPER_DONE",{
        cases:caseItems.length,users:exportInfo.users,contacts:exportInfo.contacts,
        stopped:stopRequested,folder:exportInfo.folder,xlsx:exportInfo.xlsx,
        auditStatus:exportInfo.auditStatus,missingRequested:missingRequested.length
      });
    }catch(e){
      const message=String(e?.message||e);
      if(message!=="STOP_REQUESTED"){
        emit("SCRAPER_ERROR",{message});
      }else{
        emit("SCRAPER_DONE",{
          cases:results.length,
          users:results.reduce((n,r)=>n+(r.userRows?.length||0),0),
          contacts:results.reduce((n,r)=>n+(r.contacts?.length||0),0),
          stopped:true
        });
      }
    }finally{
      runActive=false;activeControllers.clear();requestGate.clear();
    }
  }

  async function runPaymentRecap(opts={}){
    opts=stableOptions({...opts,includePaymentRecap:true,concurrency:opts.paymentConcurrency||12,requestConcurrency:opts.requestConcurrency||24});
    stopRequested=false;requestGate=new RequestGate(opts.requestConcurrency,opts.requestInterval);
    const {caseItems}=await fetchCaseListing(opts);
    const rows=[['CASE ID','CASE CODE','NAMA','DPD','TOTAL TAGIHAN','TOTAL PEMBAYARAN','SISA TAGIHAN','TANGGAL PEMBAYARAN TERAKHIR','STATUS PEMBAYARAN','CASE STATUS']];
    let next=0;
    const worker=async()=>{
      while(!stopRequested){
        const i=next++; if(i>=caseItems.length) break;
        const [caseId,obj]=caseItems[i];
        const cid=/^\d+$/.test(caseId)?Number(caseId):caseId;
        const caseName=clean(valueByLeafKey(obj,['userName','user_name','name','fullName','customerName','borrowerName']));
        let p={},name=caseName;
        try{
          // Start payment + fallback user request together. If payment already
          // contains the name, the user result is simply discarded. This cuts
          // the per-case latency when both endpoints are needed.
          const paymentPromise=requestV3(ENDPOINTS.repayPlan,{caseId:cid},`PAYMENT ${caseId}`,opts.retry);
          const userPromise=name?Promise.resolve(null):requestV3(ENDPOINTS.user,{caseId:cid},`USER INFO ${caseId}`,opts.retry);
          const [pr,ur]=await Promise.allSettled([paymentPromise,userPromise]);
          if(pr.status==='fulfilled') p=extractPaymentSummary(pr.value.data,clean(obj?.caseCode??obj?.case_code));
          else p={caseCode:clean(obj?.caseCode??obj?.case_code),name:'',totalDueAmount:null,totalPaidAmount:null,outstandingAmount:null,lastPaymentDate:'',paymentStatus:'DATA TIDAK TERSEDIA',caseStatus:'',found:false,error:String(pr.reason?.message||pr.reason||'')};
          name=clean(p.name||name);
          if(!name&&ur.status==='fulfilled'){
            const info=extractDataPayload(ur.value.data),recs=recordsFrom(info).records;
            if(recs.length){const u=normalizeUserRecord(recs[0],caseId,obj);name=clean(valueByLeafKey(u,['userName','name','fullName','customerName','borrowerName']));}
          }
        }catch(e){
          p={caseCode:clean(obj?.caseCode??obj?.case_code),name, totalDueAmount:null,totalPaidAmount:null,outstandingAmount:null,lastPaymentDate:'',paymentStatus:'DATA TIDAK TERSEDIA',caseStatus:'',found:false,error:String(e?.message||e)};
        }
        const dpd=valueByLeafKey(obj,['overdue_days','overdueDays','dpd','dpdDays','daysOverdue','days_overdue']);
        rows.push([caseId,p.caseCode||clean(obj?.caseCode??obj?.case_code),name,excelNumber(dpd)??'',amountCell(p.totalDueAmount),amountCell(p.totalPaidAmount),amountCell(p.outstandingAmount),formatPaymentDate(p.lastPaymentDate),p.paymentStatus||'DATA TIDAK TERSEDIA',p.caseStatus||'']);
        emit('SCRAPER_PROGRESS',{phase:'PAYMENT',index:i+1,total:caseItems.length});
      }
    };
    await Promise.all(Array.from({length:Math.min(opts.concurrency,Math.max(1,caseItems.length))},worker));
    const filename=`Rekap_Pembayaran_${new Date().toISOString().slice(0,10)}.xlsx`;
    if(!stopRequested) await downloadXlsx(filename,[{name:'REKAP PEMBAYARAN',rows,widths:[14,24,30,10,18,20,18,30,24,20],numberCols:{4:2,5:2,6:2,7:2,8:3},freezeCell:'A2',showGridLines:true}]);
    emit('SCRAPER_DONE',{cases:caseItems.length,users:0,contacts:0,stopped:stopRequested,folder:'Download',xlsx:stopRequested?'':filename});
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
    if (msg?.type==="START_PAYMENT_RECAP") {
      runPaymentRecap(msg.options||{}).catch(e=>emit("SCRAPER_ERROR",{message:String(e?.message||e)}));
      sendResponse({ok:true}); return true;
    }
    if (msg?.type==="START_SCRAPE") {
      run(msg.options||{}).catch(e=>emit("SCRAPER_ERROR",{message:String(e?.message||e)}));
      sendResponse({ok:true}); return true;
    }
    if (msg?.type==="STOP_SCRAPE") { stopRequested=true; abortAllRequests(); sendResponse({ok:true}); }
    if (msg?.type==="DISCOVER_AUTH") {
      // When the user switches Chrome windows/apps, the API request that
      // originally exposed the auth header may no longer be recent. Recover
      // a likely bearer token from this page's own storage instead of forcing
      // a refresh. Only token-like values from auth-named keys are returned.
      const out={};
      const looksJwt=v=>typeof v==="string" && /^Bearer\s+eyJ|^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(v.trim());
      const looksToken=v=>typeof v==="string" && v.length>=20 && v.length<=4096 && /^[A-Za-z0-9._~+\/=:-]+$/.test(v.trim());
      const authKey=k=>/(authorization|access[_-]?token|auth[_-]?token|id[_-]?token|bearer|jwt|session[_-]?token)/i.test(k);
      const scan=store=>{
        try{
          for(let i=0;i<store.length;i++){
            const k=store.key(i), v=store.getItem(k);
            if(!k || !v || !authKey(k)) continue;
            let value=v.trim();
            try {
              const parsed=JSON.parse(value);
              if(parsed && typeof parsed === "object") {
                for(const key of ["accessToken","access_token","token","authorization","idToken","id_token"]){
                  if(typeof parsed[key]==="string" && parsed[key].trim()) value=parsed[key].trim();
                }
              }
            } catch(_) {}
            if(looksJwt(value) || looksToken(value)) {
              out.authorization=/^Bearer\s+/i.test(value)?value:`Bearer ${value}`;
              return true;
            }
          }
        }catch(_){}
        return false;
      };
      scan(window.localStorage);
      if(!out.authorization) scan(window.sessionStorage);
      sendResponse({ok:true,headers:out});
      return true;
    }
    if (msg?.type==="PING") sendResponse({ok:true,url:location.href});
  });
})();